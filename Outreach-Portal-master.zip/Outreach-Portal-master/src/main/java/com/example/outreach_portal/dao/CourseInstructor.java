package com.example.outreach_portal.dao;

public interface CourseInstructor {

}

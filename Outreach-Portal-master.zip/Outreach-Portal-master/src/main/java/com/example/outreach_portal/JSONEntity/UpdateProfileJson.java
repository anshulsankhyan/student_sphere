package com.example.outreach_portal.JSONEntity;

public class UpdateProfileJson {
	
	private int user_id;
	private String value;
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	
	

}
